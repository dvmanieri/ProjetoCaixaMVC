package view;

import java.util.Scanner;

import controller.CaixaController;
import model.Caixa;

public class CaixaView {
	public void exibirSaldo(Caixa caixa) {
		System.out.println("o seu saldo �: " + caixa.getContaCorrente() + "R$\n");
	}

	public void semSaldo(Caixa caixa) {
		System.out.println("voc� n�o tem saldo o suficiente para sacar Sr.(a)");
		System.out.println("dinheiro atual: " + caixa.getContaCorrente() + "\n");
	}

	
	public void saudacao() {
		System.out.println("OL� seja bem vindo ao Banco do Senai, eu me chamo Davi\ne fui programado para fazer o seu atendimento.\n");
		System.out.println("Pode fazer as suas opera��es aqui no nosso caixa eletronico, qualquer coisa � s� me chamar =)\n");
	}
	public void inicializar() {
		

			System.out.println("====  Caixa Eletronico  ====");
			System.out.println("1. Consultar saldo. ");
			System.out.println("2. Sacar. ");
			System.out.println("3. Depositar. ");
			System.out.println("0. Sair do sistema.\n ");
	}
			
	public void sacar() {
		System.out.println("O quanto vc quer sacar hoje Sr.(a)?");
		System.out.println(" ");
	}
	public void depositar() {
		System.out.println("O quanto vc quer depositar hoje Sr.(a)?");
		System.out.println(" ");
	}
	public void numInvalido() {
		System.out.println("Numero inv�lido Sr.(a), por favor adicione novamente.  \n");
	}
}

