package model;

public class Caixa {
	private int contaCorrente;

	public Caixa(int contaCorrente) {
		super();
		this.contaCorrente = contaCorrente;
	}

	public Caixa() {
	}

	public int getContaCorrente() {
		return contaCorrente;
	}

	public void setContaCorrente(int contaCorrente) {
		this.contaCorrente = contaCorrente;
	}

}
