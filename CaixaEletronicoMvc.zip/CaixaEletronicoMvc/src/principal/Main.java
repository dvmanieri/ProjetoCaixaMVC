package principal;

import java.util.Scanner;

import controller.CaixaController;

/*Usando o Padr�o de Desenvolvimento MVC, crie um aplicativo em Java para simular um caixa eletr�nico, onde o usu�rio pode realizar apenas 4 opera��es: Consultar Saldo, Sacar, Depositar e Sair do Sistema. Crie a estrutura MVC (model, view e controller), crie as classes dentro das camadas. N�o esque�a da classe Main.
	Funcionalidade Consultar Saldo: exibe no console o saldo do usu�rio
	Funcionalidade Sacar: Solicita o valor do saque, verifica se � v�lido, exibe no console o valor do saque e atualiza saldo.
	Funcionalidade Depositar: Solicita o valor do dep�sito, atualiza o saldo e exibe o novo saldo.
	Funcionalidade Sair do Sistema: Encerra o sistema.*/

public class Main {

	public static void main(String[] args) {

		CaixaController caixa = new CaixaController();

		caixa.iniciar();

	}

}
