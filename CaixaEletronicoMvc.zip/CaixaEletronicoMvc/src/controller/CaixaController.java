package controller;

import java.util.Scanner;

import model.Caixa;
import view.CaixaView;

public class CaixaController {
	private Caixa caixa;
	private CaixaView caixaView;

	public CaixaController() {
		caixa = new Caixa();
		caixaView = new CaixaView();
	};

	public void consultarSaldo() {
		caixaView.exibirSaldo(caixa);
	}

	public void sacar(int num) {
		if (caixa.getContaCorrente() < num) {
			caixaView.semSaldo(caixa);
		} else {
			caixa.setContaCorrente(caixa.getContaCorrente() - num);
		}
	}

	public void depositar(int num) {
		caixa.setContaCorrente(caixa.getContaCorrente() + num);

	}

	public void iniciar() {
		Scanner scan = new Scanner(System.in);

		int cont = 10;
		int dinheiro = 0;

		caixaView.saudacao();

		while (cont != 0) {
			caixaView.inicializar();
			cont = scan.nextInt();

			switch (cont) {
			case 1:
				consultarSaldo();
				break;
			case 2:
				caixaView.sacar();
				dinheiro = scan.nextInt();
				sacar(dinheiro);
				break;
			case 3:
				caixaView.depositar();
				dinheiro = scan.nextInt();
				depositar(dinheiro);
				break;
			case 0:

				break;

			default:
				caixaView.numInvalido();
			}
		}
	}

}
